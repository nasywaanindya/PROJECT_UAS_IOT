#define BLYNK_TEMPLATE_ID "TMPL6KPzhVNEF"
#define BLYNK_TEMPLATE_NAME "Sensor Udara"
#define BLYNK_AUTH_TOKEN "vZM4_nBjGuugaDMqtekNGUodh6hYpmG4"
#define BLYNK_PRINT Serial

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

#define MQ2_PIN 34
#define LED_MERAH 23
#define LED_HIJAU 17
#define LED_KUNING 15

LiquidCrystal_I2C lcd(0x27, 16, 2);

char auth[] = "vZM4_nBjGuugaDMqtekNGUodh6hYpmG4";
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

BlynkTimer timer;

void sendSensor();

void setup() {
  Serial.begin(115200);
  pinMode(MQ2_PIN, INPUT);
  pinMode(LED_MERAH, OUTPUT);
  pinMode(LED_KUNING, OUTPUT);
  pinMode(LED_HIJAU, OUTPUT);

  lcd.begin();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Monitoring MQ2...");
  Serial.println("Sensor MQ2 siap digunakan");

  Blynk.begin(auth, ssid, pass);
  timer.setInterval(2000L, sendSensor);
}

void loop() {
  Blynk.run();
  timer.run();
}

void sendSensor() {
  int mq2Value = analogRead(MQ2_PIN);
  float voltage = mq2Value * (3.3 / 4095.0);

  // Serial Monitor
  Serial.print("Gas Value: ");
  Serial.print(mq2Value);
  Serial.print(" | Tegangan: ");
  Serial.println(voltage, 2);

  // LCD
  lcd.setCursor(0, 1);
  lcd.print("Gas: ");
  lcd.print(mq2Value);
  lcd.print("     ");

  // Reset semua LED fisik
  digitalWrite(LED_MERAH, LOW);
  digitalWrite(LED_KUNING, LOW);
  digitalWrite(LED_HIJAU, LOW);

  String status = "";
  String warna = "#00FF00";  // default hijau
  int ledVirtual = 255;      // LED widget ON

  if (mq2Value < 1000) {
    status = "Aman";
    digitalWrite(LED_HIJAU, HIGH);
    warna = "#00FF00"; // hijau
  } else if (mq2Value < 2000) {
    status = "Waspada";
    digitalWrite(LED_KUNING, HIGH);
    warna = "#FFFF00"; // kuning
  } else {
    status = "Bahaya!";
    digitalWrite(LED_MERAH, HIGH);
    warna = "#FF0000"; // merah
  }

  // Kirim ke Blynk
  Blynk.virtualWrite(V4, mq2Value);        // Gauge
  Blynk.virtualWrite(V5, status);          // Label
  Blynk.virtualWrite(V6, ledVirtual);      // LED nyala
  Blynk.setProperty(V6, "color", warna);   // Ubah warna LED
}
